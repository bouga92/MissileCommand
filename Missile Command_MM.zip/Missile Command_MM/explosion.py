

class Explosion:
    frame = 0
    expires = False
    
    def __init__(self, x, y):
        self.poz_x = x
        self.poz_y = y

