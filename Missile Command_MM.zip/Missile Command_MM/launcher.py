
class Launcher:
    working = True
    ammo = 10
    
    def __init__(self, x):
        self.index = x

